import os
from typing import List, Optional

import numpy as np
import torch

import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')




class VISUALIZER:
    """把模型预测结果画成图片保存到 ``save_dir``。

    - 2D 数据集：每个 ``select_index`` 输出一张 (image | ground truth | prediction) 三联图
    - 3D 数据集（BTCV 这类按切片组织的）：每个 volume 输出所有切片的分页三联图，外加一张 3D voxel 结果图
    """

    slices_per_page = 8
    voxel_target = 40

    def __init__(self, model, save_dir, dataset, select_index: Optional[List] = None,
                 device: str = 'cpu', class_nums: Optional[int] = None) -> None:
        self.model = model
        self.save_dir = save_dir
        self.dataset = dataset
        self.device = device
        self.dataset_name = getattr(dataset, 'dataset_name', 'dataset')

        config = getattr(dataset, 'config', None) or {}
        self.class_nums = class_nums or config.get('NUM_CLASSES', 2)  # 模型输出通道数
        self.num_labels = max(self.class_nums, 2)                     # 标签/配色数量（class_nums=1 时为背景+前景）
        self.palette = self._build_palette(config.get('COLOR', None))

        self.select_index = list(select_index) if select_index else self._default_select()

    # ------------------------------------------------------------------ 入口
    def __call__(self) -> str:
        self.model.eval()
        os.makedirs(self.save_dir, exist_ok=True)
        if self._is_3d():
            self._visualize_3d()
        else:
            self._visualize_2d()
        return self.save_dir

    def _is_3d(self) -> bool:
        data_list = getattr(self.dataset, 'data_list', []) or []
        return bool(data_list) and all('idx' in sample for sample in data_list)

    def _default_select(self) -> List[int]:
        if self._is_3d():
            volumes = sorted({sample['idx'] for sample in self.dataset.data_list})
            step = max(1, len(volumes) // 5)
            return volumes[::step][:5]
        length = len(self.dataset)
        step = max(1, length // 5)
        return list(range(0, length, step))[:5]

    # ------------------------------------------------------------------ 2D
    def _visualize_2d(self) -> None:
        for index in self.select_index:
            if index >= len(self.dataset):
                continue
            sample = self.dataset[index]
            pred = self._predict(sample['image'])
            panels = [
                (self._to_display(sample['image']), 'Image'),
                (self._colorize(sample['mask']), 'Ground truth'),
                (self._colorize(pred), 'Prediction'),
            ]
            fig, axes = plt.subplots(1, 3, figsize=(9, 3))
            for ax, (data, title) in zip(axes, panels):
                ax.imshow(data)
                ax.set_title(title)
                ax.axis('off')
            fig.savefig(os.path.join(self.save_dir, f'{self.dataset_name}_{index}.png'),
                        dpi=200, bbox_inches='tight')
            plt.close(fig)

    # ------------------------------------------------------------------ 3D
    def _visualize_3d(self) -> None:
        volume_slices = {}
        for index, sample in enumerate(self.dataset.data_list):
            volume_slices.setdefault(sample['idx'], []).append(index)

        for volume_index in self.select_index:
            if volume_index not in volume_slices:
                continue
            images, masks, preds = [], [], []
            for index in volume_slices[volume_index]:
                sample = self.dataset[index]
                images.append(sample['image'])
                masks.append(np.asarray(sample['mask']).astype(np.int64))
                preds.append(self._predict(sample['image']))

            self._save_slice_pages(volume_index, images, masks, preds)
            self._save_volume_voxels(volume_index, np.stack(masks), np.stack(preds))

    def _save_slice_pages(self, volume_index: int, images: List, masks: List, preds: List) -> None:
        total = len(images)
        for page, start in enumerate(range(0, total, self.slices_per_page)):
            rows = list(range(start, min(start + self.slices_per_page, total)))
            fig, axes = plt.subplots(len(rows), 3, figsize=(9, 3 * len(rows)), squeeze=False)
            for row, slice_index in enumerate(rows):
                panels = [
                    (self._to_display(images[slice_index]), f'slice {slice_index}'),
                    (self._colorize(masks[slice_index]), 'Ground truth'),
                    (self._colorize(preds[slice_index]), 'Prediction'),
                ]
                for col, (data, title) in enumerate(panels):
                    axes[row][col].imshow(data)
                    axes[row][col].set_title(title)
                    axes[row][col].axis('off')
            fig.savefig(os.path.join(self.save_dir, f'{self.dataset_name}_vol{volume_index}_slices_{page}.png'),
                        dpi=150, bbox_inches='tight')
            plt.close(fig)

    def _save_volume_voxels(self, volume_index: int, gt_volume: np.ndarray, pred_volume: np.ndarray) -> None:
        targets = [('Ground truth 3D', self._downsample(gt_volume)),
                   ('Prediction 3D', self._downsample(pred_volume))]

        fig = plt.figure(figsize=(10, 5))
        for panel, (title, volume) in enumerate(targets, start=1):
            ax = fig.add_subplot(1, 2, panel, projection='3d')
            for class_index in range(1, self.num_labels):  # 背景不画
                filled = volume == class_index
                if not filled.any():
                    continue
                ax.voxels(filled, facecolors=tuple(self.palette[class_index]), edgecolor=None)
            ax.set_title(title)
            ax.set_axis_off()

        fig.savefig(os.path.join(self.save_dir, f'{self.dataset_name}_vol{volume_index}_3d.png'),
                    dpi=150, bbox_inches='tight')
        plt.close(fig)

    def _downsample(self, volume: np.ndarray) -> np.ndarray:
        step = max(1, int(np.ceil(max(volume.shape) / self.voxel_target)))
        return volume[::step, ::step, ::step]

    # ------------------------------------------------------------------ 工具
    @torch.no_grad()
    def _predict(self, image) -> np.ndarray:
        tensor = torch.as_tensor(np.asarray(image), dtype=torch.float32).unsqueeze(0).to(self.device)
        logits = self.model(tensor)
        if isinstance(logits, (tuple, list)):
            logits = logits[0]
        if logits.shape[1] == 1:
            pred = (logits[:, 0].sigmoid() > 0.5).long()
        else:
            pred = logits.argmax(dim=1)
        return pred[0].cpu().numpy()

    def _build_palette(self, color) -> np.ndarray:
        if color:
            palette = np.zeros((self.num_labels, 3), dtype=np.float32)
            for index, value in color.items():
                if int(index) < self.num_labels:
                    palette[int(index)] = np.asarray(value, dtype=np.float32) / 255.0
            return palette
        colormap = plt.get_cmap('tab20')
        return np.asarray([colormap(i % 20)[:3] for i in range(self.num_labels)], dtype=np.float32)

    def _colorize(self, label) -> np.ndarray:
        label = np.clip(np.asarray(label).astype(np.int64), 0, self.num_labels - 1)
        return self.palette[label]

    @staticmethod
    def _to_display(image) -> np.ndarray:
        array = torch.as_tensor(np.asarray(image), dtype=torch.float32)
        if array.ndim == 3 and array.shape[0] in (1, 3):
            array = array.permute(1, 2, 0)
        array = array.numpy()
        if array.ndim == 3 and array.shape[-1] == 1:
            array = array[..., 0]
        array = array - array.min()
        return array / (array.max() + 1e-8)
