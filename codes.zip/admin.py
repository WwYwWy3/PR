import argparse
import os

import torch

from collect_component import ROOT, SEGCOLLECTOR, load_yaml


def run_train(args):
    model_configs = load_yaml(args.model_config).get('model_info', {})
    if args.model_name not in model_configs:
        raise KeyError(f'{args.model_name} 不在 {args.model_config} 中，可选: {sorted(model_configs)}')

    optimizer_config = load_yaml(os.path.join(ROOT, 'config', 'optimizer.yaml'))
    optimizer_params = optimizer_config.get('OPTIMIZER', {}).get(args.optimizer.upper())
    if optimizer_params is None:
        raise KeyError(f"{args.optimizer} 不在 config/optimizer.yaml 中，可选: {sorted(optimizer_config.get('OPTIMIZER', {}))}")

    lr_config = dict(optimizer_config.get('LR-SCHEDULER', {}))
    lr_scheduler = args.lr_scheduler or lr_config.pop('type', 'step')

    dataset_tag = os.path.splitext(os.path.basename(args.dataset))[0]
    save_dir = args.save_dir or os.path.join(ROOT, 'runs', f'{args.model_name}_{dataset_tag}')

    params = {
        'model_config': model_configs[args.model_name],
        'optimizer_params': optimizer_params,
        'lr_params': lr_config,
        'save_dir': save_dir,
        'device': args.device or ('cuda' if torch.cuda.is_available() else 'cpu'),
        'epochs': args.epochs,
        'eval_epochs': args.eval_epochs,
        'w_dice': args.w_dice,
        'w_ce': args.w_ce,
    }

    trainer, epochs, eval_epochs = SEGCOLLECTOR()(
        model_name=args.model_name,
        params=params,
        dataset=args.dataset,
        optimizer=args.optimizer,
        lr_scheduler=lr_scheduler,
    )
    return trainer.train(epochs=epochs, eval_epochs=eval_epochs)


if __name__ == '__main__':
    # models: unet, attunet, 
    parser = argparse.ArgumentParser(description='Admin tool for model training and evaluation')
    parser.add_argument('--model_config', type=str, default=os.path.join(ROOT, 'config', 'models.yaml'), help='model config')
    parser.add_argument('--model_name', type=str, default='unet', help='model name, 默认 unet')
    parser.add_argument('--dataset', type=str, default='BTCV', help='dataset name 或数据集配置路径, 默认 BTCV')
    parser.add_argument('--optimizer', type=str, default='adamw', help='optimizer, 默认 adamw')
    parser.add_argument('--save_dir', type=str, default=None, help='保存目录，默认 runs/<model_name>_<dataset>')
    parser.add_argument('--lr_scheduler', type=str, default=None, help='lr scheduler, 默认取 config/optimizer.yaml')
    parser.add_argument('--epochs', type=int, default=300, help='training epochs')
    parser.add_argument('--eval_epochs', type=int, default=1, help='evaluate every n epochs')
    parser.add_argument('--device', type=str, default=None, help='cpu / cuda, 默认自动选择')
    parser.add_argument('--w_dice', type=float, default=0.5, help='dice loss weight')
    parser.add_argument('--w_ce', type=float, default=1.0, help='cross entropy loss weight')

    run_train(parser.parse_args())
