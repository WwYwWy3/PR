"""绘图基类：样式加载、绘图流程与保存。"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Sequence

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.figure import Figure

_STYLE_DIR = Path(__file__).resolve().parent / "styles"
DEFAULT_STYLE_PATH = _STYLE_DIR / "nature.yaml"

_DEFAULT_COLORS = [
    "#4C72B0", "#DD8452", "#55A868", "#C44E52",
    "#8172B3", "#937860", "#DA8BC3", "#8C8C8C",
]

_DEFAULT_RC = {
    "font.family": "sans-serif",
    "font.size": 7,
    "axes.titlesize": 8,
    "axes.labelsize": 7,
    "axes.linewidth": 0.6,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
}


def load_style(section: str, style_path: str | Path = DEFAULT_STYLE_PATH) -> tuple[dict, dict]:
    """加载 ``style_path`` 中 ``section`` 的样式，返回 ``(rc_params, options)``。

    ``options`` 为绘图专属参数并包含 ``colors``；缺失样式文件或 PyYAML 时回退到内置默认值。
    """
    try:
        import yaml

        path = Path(style_path)
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except ImportError:
        raw = {}

    rc = dict(raw.get("rc", _DEFAULT_RC))
    colors = list(raw.get("colors", _DEFAULT_COLORS))
    options = dict(raw.get(section, {}))
    options.setdefault("colors", colors)
    return rc, options


class BasePlot:
    """绘图基类；子类需设置 ``section`` 并实现 :meth:`_draw`。"""

    section = ""

    def __init__(
        self,
        style: Optional[dict] = None,
        colors: Optional[Sequence[str]] = None,
        save_dir: Optional[str | Path] = None,
    ) -> None:
        self.rc, self.options = load_style(self.section)

        if style:
            if "colors" in style:
                self.options["colors"] = list(style["colors"])
                style = {k: v for k, v in style.items() if k != "colors"}
            self.rc.update(style)
        if colors:
            self.options["colors"] = list(colors)

        self.save_dir = Path(save_dir) if save_dir else None

    def plot(
        self,
        data: dict,
        title: str = "",
        xlabel: str = "",
        ylabel: str = "",
        *,
        figsize: Optional[tuple[float, float]] = None,
        save_name: Optional[str | Path] = None,
        **kwargs,
    ) -> tuple[Figure, Axes]:
        """绘制并返回 ``(fig, ax)``；额外关键字透传给 :meth:`_draw`。"""
        with mpl.rc_context(self.rc):
            fig, ax = plt.subplots(figsize=figsize or self.rc.get("figure.figsize", (3.5, 2.6)))
            self._draw(ax, data, title, xlabel, ylabel, **kwargs)

        if save_name:
            self.save(fig, save_name)
        return fig, ax

    def _draw(self, ax: Axes, data: dict, title: str, xlabel: str, ylabel: str, **kwargs) -> None:
        raise NotImplementedError

    @staticmethod
    def _finalize(ax: Axes, title: str, xlabel: str, ylabel: str) -> None:
        if title:
            ax.set_title(title, pad=6)
        if xlabel:
            ax.set_xlabel(xlabel)
        if ylabel:
            ax.set_ylabel(ylabel)
        ax.figure.tight_layout()

    def save(self, fig: Figure, filename: str | Path) -> Path:
        """保存图像；未设置 ``save_dir`` 时按 ``filename`` 原路径保存。"""
        path = Path(self.save_dir) / filename if self.save_dir else Path(filename)
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(
            path,
            dpi=self.rc.get("savefig.dpi", 300),
            bbox_inches=self.rc.get("savefig.bbox", "tight"),
        )
        return path
