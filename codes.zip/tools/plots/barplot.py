"""Nature 风格柱状图。"""
from __future__ import annotations

from typing import Optional

import numpy as np
from matplotlib.axes import Axes

from base import BasePlot


class BarPlot(BasePlot):
    """柱状图，数据形如 ``{"value": [...], "sem": [...], "labels": [...]}``。"""

    section = "bar"

    @staticmethod
    def _extract(data: dict) -> tuple[list[float], Optional[list[float]], list[str]]:
        values = list(data["value"])
        labels = list(data.get("labels", [str(i + 1) for i in range(len(values))]))
        errors = data.get("sem", data.get("error"))
        errors = list(errors) if errors is not None else None

        if len(labels) != len(values) or (errors is not None and len(errors) != len(values)):
            raise ValueError("value / labels / sem 长度不一致")
        return values, errors, labels

    def _draw(
        self,
        ax: Axes,
        data: dict,
        title: str,
        xlabel: str,
        ylabel: str,
        *,
        bar_width: Optional[float] = None,
        edgecolor: Optional[str] = None,
        linewidth: Optional[float] = None,
        xtick_rotation: float = 0,
        annotate: bool = False,
        value_format: str = "{:.2f}",
    ) -> None:
        values, errors, labels = self._extract(data)
        n = len(values)
        colors = self.options["colors"]

        bar_width = self.options.get("bar_width", 0.65) if bar_width is None else bar_width
        edgecolor = self.options.get("edgecolor", "black") if edgecolor is None else edgecolor
        linewidth = self.options.get("linewidth", 0.6) if linewidth is None else linewidth

        bars = ax.bar(
            np.arange(n), values, width=bar_width,
            color=[colors[i % len(colors)] for i in range(n)],
            edgecolor=edgecolor, linewidth=linewidth,
            yerr=errors, capsize=3 if errors is not None else 0,
            error_kw={
                "elinewidth": linewidth, "capthick": linewidth, "ecolor": "black",
            } if errors is not None else None,
            zorder=3,
        )

        ax.set_xticks(np.arange(n))
        ax.set_xticklabels(
            labels,
            rotation=xtick_rotation,
            ha="center" if xtick_rotation == 0 else "right",
        )

        top = max(v + (e or 0.0) for v, e in zip(values, errors or [0.0] * n))
        if top > 0:
            ax.set_ylim(0, top * 1.18)

        if annotate:
            offset = 0.01 * max(values)
            for bar, value, error in zip(bars, values, errors or [0.0] * n):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + (error or 0.0) + offset,
                    value_format.format(value),
                    ha="center", va="bottom",
                )

        self._finalize(ax, title, xlabel, ylabel)


if __name__ == "__main__":
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description="Draw a Nature-style bar plot.")
    parser.add_argument("--data", type=Path, help="JSON 数据文件路径")
    parser.add_argument("--save", type=Path, default="nature_barplot.pdf")
    args = parser.parse_args()

    data = json.loads(args.data.read_text(encoding="utf-8")) if args.data else {
        "value": [0.82, 0.75, 0.88, 0.79, 0.91],
        "sem": [0.03, 0.04, 0.02, 0.05, 0.03],
        "labels": ["U-Net", "Att-UNet", "nnU-Net", "Swin", "Ours"],
    }

    plotter = BarPlot()
    fig, _ = plotter.plot(data, xlabel="Model", ylabel="Dice score", annotate=True)
    plotter.save(fig, args.save)
