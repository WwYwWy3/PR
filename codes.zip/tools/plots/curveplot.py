"""Nature 风格折线图。"""
from __future__ import annotations

from typing import Optional

from matplotlib.axes import Axes

from base import BasePlot


class CurvePlot(BasePlot):
    """折线图。

    单条曲线：``{"x": [...], "y": [...], "label": "...", "sem": [...]}``；
    多条曲线：``{"x": [...], "series": [{"y": [...], "label": "...", "sem": [...]}, ...]}``。
    """

    section = "curve"

    @staticmethod
    def _series(data: dict) -> list[tuple[list, list, Optional[str], Optional[list]]]:
        x = list(data["x"])
        items = data.get("series", [data])
        return [
            (x, list(s.get("y", s.get("value"))), s.get("label"), s.get("sem"))
            for s in items
        ]

    def _draw(
        self,
        ax: Axes,
        data: dict,
        title: str,
        xlabel: str,
        ylabel: str,
        *,
        linewidth: Optional[float] = None,
        marker: Optional[str] = None,
        markersize: Optional[float] = None,
        legend: Optional[bool] = None,
    ) -> None:
        colors = self.options["colors"]
        linewidth = self.options.get("linewidth", 1.2) if linewidth is None else linewidth
        marker = self.options.get("marker", "o") if marker is None else marker
        markersize = self.options.get("markersize", 4) if markersize is None else markersize
        capsize = self.options.get("capsize", 3)

        series = self._series(data)
        for i, (x, y, label, sem) in enumerate(series):
            ax.errorbar(
                x, y, yerr=sem,
                color=colors[i % len(colors)],
                linewidth=linewidth, marker=marker, markersize=markersize,
                capsize=capsize if sem is not None else 0,
                label=label,
            )

        if legend is None:
            legend = len(series) > 1 or any(s[2] for s in series)
        if legend:
            ax.legend()

        self._finalize(ax, title, xlabel, ylabel)


if __name__ == "__main__":
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description="Draw a Nature-style line plot.")
    parser.add_argument("--data", type=Path, help="JSON 数据文件路径")
    parser.add_argument("--save", type=Path, default="nature_curveplot.pdf")
    args = parser.parse_args()

    data = json.loads(args.data.read_text(encoding="utf-8")) if args.data else {
        "x": [1, 2, 3, 4],
        "series": [
            {"y": [0.82, 0.84, 0.87, 0.89], "label": "U-Net", "sem": [0.02, 0.02, 0.03, 0.03]},
            {"y": [0.85, 0.88, 0.90, 0.91], "label": "Ours", "sem": [0.01, 0.02, 0.02, 0.02]},
        ],
    }

    plotter = CurvePlot()
    fig, _ = plotter.plot(data, xlabel="Epoch", ylabel="Dice score")
    plotter.save(fig, args.save)
