import os
import sys
from typing import Any, Dict, List, Tuple

from monai.metrics import DiceMetric, MeanIoU, SurfaceDistanceMetric
import numpy as np
import torch
import torch.nn.functional as F

def calc_asd(pred: torch.Tensor, gt: torch.Tensor, class_nums: int, include_background: bool = False, symmetric: bool = True, distance_metric = "euclidean", reduction: str = "mean"):
    asd_metric = SurfaceDistanceMetric(
        include_background=include_background,
        symmetric=symmetric,          # 是否计算对称 ASD，建议 True
        distance_metric=distance_metric,
        reduction=reduction
    )
    gt = transform_multi_to_onehot(gt, class_nums)
    asd_metric(y_pred = pred, y = gt)
    result = asd_metric.aggregate().item()
    return result

def calc_iou(pred: torch.Tensor, gt: torch.Tensor, class_nums: int, include_background: bool = False, reduction: str = "mean"):
    IoU_metric = MeanIoU(include_background=include_background, reduction=reduction)
    gt = transform_multi_to_onehot(gt, class_nums)
    IoU_metric(y_pred = pred, y = gt)
    result = IoU_metric.aggregate().item()
    return result

def calc_dice(pred: torch.Tensor, gt: torch.Tensor, class_nums: int, have_channel: bool = True, include_background: bool = False, reduction: str = "mean"):
    dice_metric = DiceMetric(include_background=include_background, reduction="mean")
    gt = transform_multi_to_onehot(gt, class_nums, have_channel)
    dice_metric(y_pred = pred, y = gt)
    result = dice_metric.aggregate().item()
    return result

def transform_multi_to_onehot(gt: torch.Tensor, class_nums: int, have_channel: bool = False):
    # gt: [batch, 1, ...] 或 [batch, ...]，2D / 3D 通用
    if have_channel:
        gt_ = gt.squeeze(1).to(torch.long)
    else:
        gt_ = gt.to(torch.long)
    gt_onehot = F.one_hot(gt_, num_classes = class_nums).movedim(-1, 1).float() # [batch, class_nums, ...]
    return gt_onehot

class evaluator:
    def __init__(self):
        pass

class Evaluator:
    """累积式分割指标，2D / 3D 通用（MONAI 按张量维数自动推断空间维）。
    用法:
        ev = Evaluator(class_nums=14)
        ev.update(pred, gt)     # pred: [B, C, ...] logits; gt: [B, ...] label map
        metrics = ev.compute()  # {'dice': ..., 'iou': ...}
        ev.reset()
    """
    def __init__(self, class_nums: int, include_background: bool = False,
                 gt_have_channel: bool = False, metrics: Tuple[str, ...] = ("dice", "iou")) -> None:
        self.class_nums = class_nums
        self.gt_have_channel = gt_have_channel
        self.metrics: Dict[str, Any] = {}
        if "dice" in metrics:
            self.metrics["dice"] = DiceMetric(include_background=include_background, reduction="mean")
        if "iou" in metrics:
            self.metrics["iou"] = MeanIoU(include_background=include_background, reduction="mean")

    @torch.no_grad()
    def update(self, pred: torch.Tensor, gt: torch.Tensor) -> None:
        # pred logits [B, C, ...] -> 类别索引 [B, ...]；class_nums == 1 时按 sigmoid 0.5 二值化
        if self.class_nums == 1:
            label = (pred[:, 0].sigmoid() > 0.5).long()
            num_labels = 2
        else:
            label = pred.argmax(dim=1)
            num_labels = self.class_nums
        y_pred = transform_multi_to_onehot(label, num_labels)
        y = transform_multi_to_onehot(gt, num_labels, self.gt_have_channel)
        for metric in self.metrics.values():
            metric(y_pred = y_pred, y = y)

    def compute(self) -> Dict[str, float]:
        return {name: float(metric.aggregate().item()) for name, metric in self.metrics.items()}

    def reset(self) -> None:
        for metric in self.metrics.values():
            metric.reset()

if __name__ == '__main__':
    # 1. 初始化指标（通常忽略背景类，只算前景 Dice）
    dice_metric = DiceMetric(include_background=False, reduction="mean")
    path = '/mnt/f/PatternRecognition/codes/datasets/BTCV/processed_data/mask/label0026/75.npz'
    x = torch.tensor(np.load(path)['mask']).unsqueeze(0).unsqueeze(0).repeat(4, 1, 1, 1) # (512, 512)
    y = transform_multi_to_onehot(x, 14)
    res = calc_dice(y, x, 14)
    print(res)

    


