import copy
import os
from typing import Dict, Tuple

from dataloader import create_dataloader
from models import create_baseline
from models.BASELINE.segmentation.loss import LossFunction
from utils import Evaluator, TRAINER, create_optimizer_lr_scheduler

ROOT = os.path.dirname(os.path.abspath(__file__))
# 不同模型的类别数参数名不统一，按顺序取第一个命中的
CLASS_NUM_KEYS = ('class_nums', 'num_classes', 'out_channels')


def load_yaml(path: str) -> Dict:
    import yaml

    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def _override_param(model_params: Dict, value: int, keys: tuple, name: str) -> Dict:
    params = dict(model_params)
    for key in keys:
        if key in params:
            params[key] = value
            return params
    raise KeyError(f'model config 里没有{name}参数，期望 {keys} 之一')


def _eval_augmentation(aug_config: Dict) -> Dict:
    """验证/可视化不需要随机增强，把所有随机操作的 p 置 0。"""
    config = copy.deepcopy(aug_config)
    for operation in config.get('OPERATIONS', {}).values():
        if 'p' in operation:
            operation['p'] = 0.0
    return config


class SEGCOLLECTOR:
    """按 (模型, 数据集, 优化器, 调度器) 组装出可直接训练的 TRAINER。"""

    def __call__(
        self,
        model_name: str,
        params: Dict,
        dataset: str,
        optimizer: str,
        lr_scheduler: str,
    ) -> Tuple[TRAINER, int, int]:
        dataset_path = dataset if os.path.isfile(dataset) else os.path.join(ROOT, 'config', 'datasets', f'{dataset}.yaml')
        dataset_config = load_yaml(dataset_path)
        augmentation = params.get('augmentation') or load_yaml(os.path.join(ROOT, 'config', 'datasets', 'augmentation.yaml'))
        dataset_info = dataset_config['DATASET']
        class_nums = dataset_info['NUM_CLASSES']

        model_params = _override_param(params['model_config'], class_nums, CLASS_NUM_KEYS, '类别数')
        model = create_baseline(model_name, model_params)

        train_loader = create_dataloader('segmentation', 'train', dataset_config, augmentation)
        validate_loader = create_dataloader('segmentation', 'validation', dataset_config, _eval_augmentation(augmentation))

        optimizer_obj, lr_scheduler_obj = create_optimizer_lr_scheduler(
            optimizer,
            lr_scheduler,
            model.parameters(),
            params.get('optimizer_params', {}),
            params.get('lr_params', {}),
        )

        criterion = LossFunction(
            w_dice=params.get('w_dice', 0.5),
            w_ce=params.get('w_ce', 1.0),
            class_nums=class_nums,
        )
        evaluator = Evaluator(class_nums=class_nums, include_background=False)

        trainer_params = {
            'model': model,
            'model_name': model_name,
            'optimizer': optimizer_obj,
            'lr_scheduler': lr_scheduler_obj,
            'criterion': criterion,
            'train_loader': train_loader,
            'validate_loader': validate_loader,
            'weight_save_dir': params['save_dir'],
            'evaluator': evaluator,
            'device': params.get('device', 'cpu'),
            'dataset_name': dataset_info['NAME'],
            'select_index': params.get('select_index', None),
        }
        compare_fun = params.get('compare_fun') or (lambda new, best: not best or new.get('dice', 0) > best.get('dice', 0))

        trainer = TRAINER(trainer_params, compare_fun=compare_fun)
        return trainer, params.get('epochs', 300), params.get('eval_epochs', 1)
